﻿using System;

namespace human
{
    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
