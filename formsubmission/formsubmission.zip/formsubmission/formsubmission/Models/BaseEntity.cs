using Microsoft.AspNetCore.Mvc;

namespace formsubmission.Models
{
    public abstract class BaseEntity {}
}