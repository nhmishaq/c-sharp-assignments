﻿using System;
using Human;

namespace wizard_ninja_samurai
{
    class Program
    {
        static void Main(string[] args)
        {
        
        }
    }
}
